import { Student } from '../data/students';

export interface PredictionResult {
  predictedScore: number;
  neighbors: Student[];
}

/**
 * Calculates the Euclidean distance between two students based on normalized features.
 */
function calculateDistance(s1: Partial<Student>, s2: Student): number {
  // Normalization factors (approximate ranges)
  const studyHoursRange = 20;
  const attendanceRange = 100;
  const previousGradeRange = 100;
  const sleepHoursRange = 12;
  const extracurricularHoursRange = 10;
  const familySupportRange = 5;

  const d1 = Math.pow(((s1.studyHours || 0) - s2.studyHours) / studyHoursRange, 2);
  const d2 = Math.pow(((s1.attendance || 0) - s2.attendance) / attendanceRange, 2);
  const d3 = Math.pow(((s1.previousGrade || 0) - s2.previousGrade) / previousGradeRange, 2);
  const d4 = Math.pow(((s1.sleepHours || 0) - s2.sleepHours) / sleepHoursRange, 2);
  const d5 = Math.pow(((s1.extracurricularHours || 0) - s2.extracurricularHours) / extracurricularHoursRange, 2);
  const d6 = Math.pow(((s1.familySupport || 0) - s2.familySupport) / familySupportRange, 2);

  return Math.sqrt(d1 + d2 + d3 + d4 + d5 + d6);
}

/**
 * KNN Algorithm implementation
 * @param input The student data to predict for
 * @param dataset The training dataset
 * @param k Number of neighbors
 */
export function predictPerformance(
  input: Omit<Student, 'id' | 'performance'>,
  dataset: Student[],
  k: number = 3
): PredictionResult {
  // 1. Calculate distances to all points in dataset
  const distances = dataset.map(student => ({
    student,
    distance: calculateDistance(input, student)
  }));

  // 2. Sort by distance
  distances.sort((a, b) => a.distance - b.distance);

  // 3. Get top K neighbors
  const neighbors = distances.slice(0, k).map(d => d.student);

  // 4. Calculate average performance of neighbors
  const sum = neighbors.reduce((acc, curr) => acc + curr.performance, 0);
  const predictedScore = Math.round(sum / k);

  return {
    predictedScore,
    neighbors
  };
}
